'''
Utility Script to change the chunking format of a set of annotations.
'''

import os
import sys
import codecs
import re
import argparse

def conll_to_bmes(conll):
    conll = f.read().split('\n')
    pairs = [re.sub('\s+', ' ', e).split() for e in conll]
    pairs = [p + [''] * (2 - len(p)) for p in pairs]
    tokens, labels = zip(*pairs)
    
    new_labs = []
    for i, l in enumerate(labels):
        if l.startswith('B-'):
            if (i == len(labels) - 1) or labels[i + 1] != l.replace('B-', 'I-'):
                new_labs.append(l.replace('B-', 'S-'))
            else:
                new_labs.append(l)
        elif l.startswith('I-'):
            if (i == len(labels) - 1) or labels[i + 1] != l:
                new_labs.append(l.replace('I-', 'E-'))
            else:
                new_labs.append(l)
        else:
            new_labs.append(l)
    new_pairs = list(zip(*[tokens, new_labs]))
    bmes = '\n'.join('\t '.join(p) for p in new_pairs)
    
    return bmes

if __name__ == '__main__':
    parser = argparse.ArgumentParser('<script>')